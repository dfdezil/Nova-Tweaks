param(
    [string]$NipPath = "$PSScriptRoot\NovaNvidiaProfile.nip"
)

$ErrorActionPreference = "SilentlyContinue"

try {
    $nvpiPath = "$PSScriptRoot\nvidiaProfileInspector.exe"
    if (-not (Test-Path $nvpiPath)) {
        Write-Host "nvidiaProfileInspector.exe not found."
        exit 1
    }
    if (-not (Test-Path $NipPath)) {
        Write-Host "NIP profile not found: $NipPath"
        exit 1
    }

    $asm = [System.Reflection.Assembly]::LoadFile($nvpiPath)
    $bsType = $asm.GetType("nvidiaProfileInspector.AppBootstrapper")
    $bs = [System.Activator]::CreateInstance($bsType)
    try { $bs.Initialize() } catch {}

    $serviceType = $asm.GetType("nvidiaProfileInspector.Common.DrsImportService")
    $importService = $bs.Resolve($serviceType)

    $importService.ImportProfiles($NipPath) | Out-Null
    Write-Host "SUCCESS"
    exit 0
} catch {
    Write-Host "Error: $($_.Exception.Message)"
    exit 1
}
